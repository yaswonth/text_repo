---
pageid: expr.empty
title: empty
layout: docs
section: Expression Terms
permalink: docs/expr/empty.html
---

Evaluates as true if the file exists, has size 0 and is a regular file or
directory.

    "empty"
    ["empty"]



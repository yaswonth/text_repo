---
pageid: expr.not
title: not
layout: docs
section: Expression Terms
permalink: docs/expr/not.html
---

The `not` expression inverts the result of the subexpression argument:

    ["not", "empty"]
